
import os
import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from ml_engine import MLPredictor

INPUT_FILE = "/app/pm25_historical.csv"
OUTPUT_DIR = "/app/task3_output"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# Load historical PM2.5 readings
df = pd.read_csv(INPUT_FILE)

# Convert Unix milliseconds into DateTime
df["Timestamp"] = pd.to_datetime(
    df["Timestamp"], unit="ms", errors="coerce"
)
df["Value"] = pd.to_numeric(df["Value"], errors="coerce")

# Clean and sort the data
df = df.dropna(subset=["Timestamp", "Value"])
df = df.drop_duplicates()
df = df.sort_values("Timestamp").reset_index(drop=True)

print("Cleaned records:", len(df))
print("Final two PM2.5 values:", df["Value"].tail(2).tolist())

df.to_csv(
    os.path.join(OUTPUT_DIR, "cleaned_pm25.csv"),
    index=False
)

# Calculate 10-minute averages
averaged_df = (
    df.set_index("Timestamp")["Value"]
    .resample("10min")
    .mean()
    .dropna()
    .reset_index()
)

averaged_df.columns = ["Timestamp", "Value"]

print("10-minute averaged records:", len(averaged_df))

averaged_df.to_csv(
    os.path.join(OUTPUT_DIR, "pm25_10min_average.csv"),
    index=False
)

# Train the supplied Prophet ML Engine
pm25_df = averaged_df[["Timestamp", "Value"]].copy()

predictor = MLPredictor(pm25_df)
predictor.train()

# Generate exactly 12 future intervals (2 hours)
future = predictor._MLPredictor__trainer.make_future_dataframe(
    periods=12,
    freq="10min"
)

forecast = predictor._MLPredictor__trainer.predict(future)

# Save complete forecast
forecast.to_csv(
    os.path.join(OUTPUT_DIR, "pm25_forecast.csv"),
    index=False
)

# Save prediction graph
fig = predictor.plot_result(forecast)

fig.savefig(
    os.path.join(OUTPUT_DIR, "pm25_prediction.png"),
    dpi=300,
    bbox_inches="tight"
)

plt.close(fig)

print("Forecast rows:", len(forecast))
print("Future prediction intervals:", 12)
print("Task 3 pipeline completed successfully.")
