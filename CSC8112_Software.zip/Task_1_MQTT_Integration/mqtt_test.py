import csv
import json
import time
import paho.mqtt.client as mqtt

BROKER = "localhost"
PORT = 1883
TOPIC = "sensors/pm25"

client = mqtt.Client()
client.connect(BROKER, PORT, 60)

with open("pm25_historical.csv", newline="") as file:
    reader = csv.DictReader(file)

    for row in reader:
        message = {
            "timestamp": int(row["Timestamp"]),
            "value": float(row["Value"])
        }

        if message["value"] > 50:
            print("OUTLIER:", message)

        client.publish(TOPIC, json.dumps(message))
        print("Published:", message)

        time.sleep(0.1)

client.disconnect()
