
import os
import json
import time
import queue
import threading
import requests
import paho.mqtt.client as mqtt

# MQTT configuration
BROKER = os.getenv("MQTT_BROKER", "mosquitto")
PORT = int(os.getenv("MQTT_PORT", "1883"))

IMAGE_TOPIC = "camera/annotated"
COUNT_TOPIC = "camera/vehicle_count"
CLASSIFICATION_TOPIC = "sensors/pm25/classification"

# Dashboard API
DASHBOARD_URL = "http://dashboard.cloud.ncl.ac.uk:8000/api/records"

# Latest received data
latest_image = None
latest_reading = None

data_lock = threading.Lock()
post_queue = queue.Queue()

# MQTT client
client = mqtt.Client(
    callback_api_version=mqtt.CallbackAPIVersion.VERSION2
)


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("Connected to MQTT broker")

        client.subscribe([
            (IMAGE_TOPIC, 1),
            (COUNT_TOPIC, 1),
            (CLASSIFICATION_TOPIC, 1)
        ])

        print("Subscribed to:")
        print(IMAGE_TOPIC)
        print(COUNT_TOPIC)
        print(CLASSIFICATION_TOPIC)

    else:
        print("MQTT connection failed:", reason_code)


def on_message(client, userdata, message):
    global latest_image, latest_reading

    try:
        with data_lock:

            # F1: Store the latest annotated JPEG image
            if message.topic == IMAGE_TOPIC:
                latest_image = message.payload
                print("Latest annotated image updated")

            # F1: Store the latest PM2.5 classification
            elif message.topic == CLASSIFICATION_TOPIC:
                reading = json.loads(message.payload.decode())

                latest_reading = reading
                print("Latest PM2.5 reading updated:", reading)

            # F2: Check vehicle count
            elif message.topic == COUNT_TOPIC:
                count_data = json.loads(message.payload.decode())

                vehicle_count = int(count_data["vehicle_count"])

                print("Vehicle count received:", vehicle_count)

                if vehicle_count > 5:

                    if latest_image is None or latest_reading is None:
                        print("Required image or PM2.5 reading missing")
                        return

                    # Take a snapshot of the latest available data
                    image_copy = latest_image
                    reading_copy = latest_reading.copy()

                    post_queue.put({
                        "image": image_copy,
                        "reading": reading_copy,
                        "vehicle_count": vehicle_count
                    })

                    print("Vehicle count exceeds 5. Record queued.")

                else:
                    print("Vehicle count does not exceed 5. Frame dropped.")

    except Exception as error:
        print("MQTT processing error:", error)


def dashboard_worker():
    print("Dashboard posting worker started")

    while True:
        record = post_queue.get()

        try:
            reading = record["reading"]

            # Convert milliseconds to Unix seconds
            timestamp = float(reading["timestamp"]) / 1000

            value = float(reading["value"])
            predicted_quality = str(
                reading["predicted_quality"]
            ).title()

            # F3: Send the record to the dashboard
            data = {
                "timestamp": timestamp,
                "value": value,
                "predicted_quality": predicted_quality
            }

            files = {
                "image": (
                    "annotated.jpg",
                    record["image"],
                    "image/jpeg"
                )
            }

            response = requests.post(
                DASHBOARD_URL,
                data=data,
                files=files,
                timeout=30
            )

            if response.ok:
                print("Dashboard record submitted successfully")
                print("HTTP status:", response.status_code)
                print("Timestamp:", timestamp)
                print("PM2.5 value:", value)
                print("Predicted quality:", predicted_quality)
                print("Vehicle count:", record["vehicle_count"])
            else:
                print("Dashboard rejected the record")
                print("HTTP status:", response.status_code)
                print("Response:", response.text[:500])

        except Exception as error:
            print("Dashboard submission error:", error)

        finally:
            post_queue.task_done()


# Start the dashboard worker separately
worker = threading.Thread(
    target=dashboard_worker,
    daemon=True
)
worker.start()

client.on_connect = on_connect
client.on_message = on_message

print("Connecting to MQTT broker...")
client.connect(BROKER, PORT, 60)

print("Waiting for MQTT messages...")
client.loop_forever()
