
import json
import os
import numpy as np
import paho.mqtt.client as mqtt
import tensorflow as tf

# MQTT configuration
BROKER = os.getenv("MQTT_BROKER", "mosquitto")
PORT = int(os.getenv("MQTT_PORT", "1883"))

INPUT_TOPIC = "sensors/pm25"
OUTPUT_TOPIC = "sensors/pm25/classification"

# Model files
MODEL_PATH = "/app/pm25_classifier.tflite"
CONFIG_PATH = "/app/model_config.json"

# Load model configuration
with open(CONFIG_PATH, "r") as file:
    config = json.load(file)

CLASS_NAMES = config["class_names"]
FEATURE_MEAN = float(config["feature_mean"])
FEATURE_STD = float(config["feature_std"])

# Load TensorFlow Lite model
interpreter = tf.lite.Interpreter(model_path=MODEL_PATH)
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()


def classify_reading(timestamp, value):
    scaled_value = (float(value) - FEATURE_MEAN) / FEATURE_STD

    input_data = np.array([[scaled_value]], dtype=np.float32)

    interpreter.set_tensor(
        input_details[0]["index"],
        input_data
    )

    interpreter.invoke()

    probabilities = interpreter.get_tensor(
        output_details[0]["index"]
    )[0]

    predicted_index = int(np.argmax(probabilities))
    predicted_quality = CLASS_NAMES[predicted_index]

    return {
        "timestamp": timestamp,
        "value": float(value),
        "predicted_quality": predicted_quality
    }


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT broker")
        client.subscribe(INPUT_TOPIC)
        print("Subscribed to:", INPUT_TOPIC)
    else:
        print("MQTT connection failed:", rc)


def on_message(client, userdata, message):
    try:
        reading = json.loads(message.payload.decode("utf-8"))

        timestamp = reading["timestamp"]
        value = reading["value"]

        result = classify_reading(timestamp, value)

        client.publish(
            OUTPUT_TOPIC,
            json.dumps(result),
            qos=1
        )

        print("Published classification:", result)

    except Exception as error:
        print("Message processing error:", error)


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect(BROKER, PORT, 60)

print("Waiting for PM2.5 readings...")
client.loop_forever()
