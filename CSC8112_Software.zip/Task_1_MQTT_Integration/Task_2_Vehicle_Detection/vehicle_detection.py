

import os
import json
import time
import cv2
import numpy as np
import paho.mqtt.client as mqtt

from ultralytics import YOLO

# MQTT configuration
BROKER = os.getenv("MQTT_BROKER", "mosquitto")
PORT = int(os.getenv("MQTT_PORT", "1883"))

INPUT_TOPIC = "camera/frames"
IMAGE_TOPIC = "camera/annotated"
COUNT_TOPIC = "camera/vehicle_count"

# Model configuration
MODEL_PATH = os.getenv("YOLO_MODEL", "yolov8n.pt")
CONFIDENCE = 0.35

# COCO vehicle class IDs:
# bicycle=1, car=2, motorcycle=3, bus=5, truck=7
VEHICLE_CLASSES = [1, 2, 3, 5, 7]

print("Loading YOLO model:", MODEL_PATH)
model = YOLO(MODEL_PATH)

client = mqtt.Client(
    callback_api_version=mqtt.CallbackAPIVersion.VERSION2
)


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("Connected to MQTT broker")
        client.subscribe(INPUT_TOPIC, qos=1)
        print("Subscribed to:", INPUT_TOPIC)
    else:
        print("MQTT connection failed:", reason_code)


def on_message(client, userdata, message):
    try:
        # Decode incoming JPEG bytes
        image_array = np.frombuffer(message.payload, dtype=np.uint8)
        frame = cv2.imdecode(image_array, cv2.IMREAD_COLOR)

        if frame is None:
            print("Invalid camera image received")
            return

        # Perform YOLO inference
        results = model.predict(
            source=frame,
            conf=CONFIDENCE,
            classes=VEHICLE_CLASSES,
            verbose=False
        )

        annotated_frame = frame.copy()
        vehicle_count = 0
        detected_vehicles = []

        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(
                    int, box.xyxy[0].tolist()
                )

                class_id = int(box.cls[0].item())
                confidence = float(box.conf[0].item())
                vehicle_name = model.names[class_id]

                vehicle_count += 1
                detected_vehicles.append(vehicle_name)

                # Draw red bounding box
                cv2.rectangle(
                    annotated_frame,
                    (x1, y1),
                    (x2, y2),
                    (0, 0, 255),
                    2
                )

                label = f"{vehicle_name}: {confidence:.2f}"

                cv2.putText(
                    annotated_frame,
                    label,
                    (x1, max(y1 - 10, 20)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (0, 0, 255),
                    2
                )

        # Encode annotated image as JPEG
        success, encoded_image = cv2.imencode(
            ".jpg", annotated_frame
        )

        if not success:
            print("Could not encode annotated image")
            return

        # Publish annotated image
        client.publish(
            IMAGE_TOPIC,
            encoded_image.tobytes(),
            qos=1
        )

        # Publish vehicle count and detection details
        count_message = {
            "timestamp": int(time.time() * 1000),
            "vehicle_count": vehicle_count,
            "vehicles": detected_vehicles
        }

        client.publish(
            COUNT_TOPIC,
            json.dumps(count_message),
            qos=1
        )

        print("Vehicles detected:", vehicle_count)
        print("Published annotated image and vehicle count")

    except Exception as error:
        print("Image processing error:", error)


client.on_connect = on_connect
client.on_message = on_message

print("Connecting to MQTT broker...")
client.connect(BROKER, PORT, 60)

print("Waiting for camera frames...")
client.loop_forever()
