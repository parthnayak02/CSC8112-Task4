cd ~/CSC8112/CSC8112

python - <<'PY'
import json
import csv

with open("data/uo_data.min.json") as f:
    source = json.load(f)

records = source["sensors"][0]["data"]["PM2.5"]

with open("../task1/pm25_historical.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Timestamp", "Value"])

    for record in records:
        writer.writerow([record["Timestamp"], record["Value"]])

print("Exported records:", len(records))
print("Output: ../task1/pm25_historical.csv")
print("Last two values:", [r["Value"] for r in records[-2:]])
PY
