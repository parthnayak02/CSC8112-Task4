
import time
import json
import requests
import paho.mqtt.client as mqtt

SENSOR_URL = "http://smartcam.uo.ncl.ac.uk:8001/sensor"
CAMERA_URL = "http://smartcam.uo.ncl.ac.uk:8001/camera"

BROKER = "mosquitto"
PORT = 1883

PM25_TOPIC = "sensors/pm25"
CAMERA_TOPIC = "camera/frames"

POLL_INTERVAL = 5

client = mqtt.Client()
client.connect(BROKER, PORT, 60)
client.loop_start()

session = requests.Session()
seen_timestamps = set()


def collect_sensor_data():
    try:
        response = session.get(SENSOR_URL, timeout=15)
        response.raise_for_status()

        records = response.json()

        if not isinstance(records, list):
            print("Unexpected sensor response format")
            return

        for record in records:
            if record.get("Variable") != "PM2.5":
                continue

            timestamp = record.get("Timestamp")
            value = record.get("Value")

            if timestamp is None or value is None:
                continue

            timestamp = int(timestamp)
            value = float(value)

            if timestamp in seen_timestamps:
                continue

            seen_timestamps.add(timestamp)

            if value > 50:
                print("PM2.5 OUTLIER:", value)

            message = {
                "Timestamp": timestamp,
                "Value": value
            }

            result = client.publish(
                PM25_TOPIC,
                json.dumps(message),
                qos=1
            )

            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                print("PM2.5 published:", message)
            else:
                print("PM2.5 publishing failed:", result.rc)

    except (requests.RequestException, ValueError, TypeError) as error:
        print("Sensor collection error:", error)


def collect_camera_frame():
    try:
        response = session.get(CAMERA_URL, timeout=20)
        response.raise_for_status()

        if not response.content:
            print("Camera returned an empty image")
            return

        result = client.publish(
            CAMERA_TOPIC,
            response.content,
            qos=1
        )

        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            print("Camera frame published:",
                  len(response.content), "bytes")
        else:
            print("Camera publishing failed:", result.rc)

    except requests.RequestException as error:
        print("Camera collection error:", error)


try:
    print("Starting live sensor and camera collector...")

    while True:
        collect_sensor_data()
        collect_camera_frame()
        time.sleep(POLL_INTERVAL)

except KeyboardInterrupt:
    print("\nCollector stopped by user.")

finally:
    client.loop_stop()
    client.disconnect()
    session.close()
