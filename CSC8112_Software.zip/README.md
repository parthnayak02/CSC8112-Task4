# CSC8112 IoT Assessment Project

This package contains the implementation files, Docker configurations,
models, datasets and generated outputs for Tasks 1 to 5.

## Requirements

- Docker Engine
- Docker Compose plugin
- Internet connection for downloading base images and dependencies

## Run Tasks 1, 2, 4 and 5

Open a terminal in Task_1_MQTT_Integration:

    cd Task_1_MQTT_Integration

Build and start the integrated services:

    docker compose up --build -d

Check service status:

    docker compose ps

View service logs:

    docker compose logs -f

Stop services:

    docker compose down

## Run Task 3

Open a terminal in Task_3_PM25_Forecasting:

    cd Task_3_PM25_Forecasting

Build and run the forecasting pipeline:

    docker compose up --build

Forecast CSV files and the prediction graph are saved in task3_output.

## Notes

Docker images and Python virtual environments are not included.
The supplied Dockerfiles and requirements files are used to rebuild
the services.
